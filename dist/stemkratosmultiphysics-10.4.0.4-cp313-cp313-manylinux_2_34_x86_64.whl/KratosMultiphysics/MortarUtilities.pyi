import KratosMultiphysics as Kratos
import KratosMultiphysics as Kratos
import typing
from typing import overload

def ComputeNodesMeanNormalModelPart(arg0: Kratos.ModelPart, arg1: bool) -> None:
    """ComputeNodesMeanNormalModelPart(arg0: Kratos.ModelPart, arg1: bool) -> None"""
def ComputeNodesTangentFromNormalModelPart(arg0: Kratos.ModelPart) -> None:
    """ComputeNodesTangentFromNormalModelPart(arg0: Kratos.ModelPart) -> None"""
@overload
def ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat, arg3: bool) -> None:
    """ComputeNodesTangentModelPart(*args, **kwargs)
    Overloaded function.

    1. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat, arg3: bool) -> None

    2. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat, arg2: bool) -> None

    3. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None

    4. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat) -> None

    5. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> None

    6. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart) -> None
    """
@overload
def ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat, arg2: bool) -> None:
    """ComputeNodesTangentModelPart(*args, **kwargs)
    Overloaded function.

    1. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat, arg3: bool) -> None

    2. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat, arg2: bool) -> None

    3. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None

    4. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat) -> None

    5. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> None

    6. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart) -> None
    """
@overload
def ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None:
    """ComputeNodesTangentModelPart(*args, **kwargs)
    Overloaded function.

    1. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat, arg3: bool) -> None

    2. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat, arg2: bool) -> None

    3. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None

    4. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat) -> None

    5. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> None

    6. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart) -> None
    """
@overload
def ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat) -> None:
    """ComputeNodesTangentModelPart(*args, **kwargs)
    Overloaded function.

    1. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat, arg3: bool) -> None

    2. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat, arg2: bool) -> None

    3. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None

    4. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat) -> None

    5. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> None

    6. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart) -> None
    """
@overload
def ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> None:
    """ComputeNodesTangentModelPart(*args, **kwargs)
    Overloaded function.

    1. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat, arg3: bool) -> None

    2. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat, arg2: bool) -> None

    3. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None

    4. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat) -> None

    5. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> None

    6. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart) -> None
    """
@overload
def ComputeNodesTangentModelPart(arg0: Kratos.ModelPart) -> None:
    """ComputeNodesTangentModelPart(*args, **kwargs)
    Overloaded function.

    1. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat, arg3: bool) -> None

    2. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat, arg2: bool) -> None

    3. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None

    4. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: typing.SupportsFloat) -> None

    5. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> None

    6. ComputeNodesTangentModelPart(arg0: Kratos.ModelPart) -> None
    """
@overload
def InvertNormal(arg0: Kratos.ElementsArray) -> None:
    """InvertNormal(*args, **kwargs)
    Overloaded function.

    1. InvertNormal(arg0: Kratos.ElementsArray) -> None

    2. InvertNormal(arg0: Kratos.ConditionsArray) -> None

    3. InvertNormal(arg0: Kratos.ElementsArray, arg1: Kratos.Flags) -> None

    4. InvertNormal(arg0: Kratos.ConditionsArray, arg1: Kratos.Flags) -> None
    """
@overload
def InvertNormal(arg0: Kratos.ConditionsArray) -> None:
    """InvertNormal(*args, **kwargs)
    Overloaded function.

    1. InvertNormal(arg0: Kratos.ElementsArray) -> None

    2. InvertNormal(arg0: Kratos.ConditionsArray) -> None

    3. InvertNormal(arg0: Kratos.ElementsArray, arg1: Kratos.Flags) -> None

    4. InvertNormal(arg0: Kratos.ConditionsArray, arg1: Kratos.Flags) -> None
    """
@overload
def InvertNormal(arg0: Kratos.ElementsArray, arg1: Kratos.Flags) -> None:
    """InvertNormal(*args, **kwargs)
    Overloaded function.

    1. InvertNormal(arg0: Kratos.ElementsArray) -> None

    2. InvertNormal(arg0: Kratos.ConditionsArray) -> None

    3. InvertNormal(arg0: Kratos.ElementsArray, arg1: Kratos.Flags) -> None

    4. InvertNormal(arg0: Kratos.ConditionsArray, arg1: Kratos.Flags) -> None
    """
@overload
def InvertNormal(arg0: Kratos.ConditionsArray, arg1: Kratos.Flags) -> None:
    """InvertNormal(*args, **kwargs)
    Overloaded function.

    1. InvertNormal(arg0: Kratos.ElementsArray) -> None

    2. InvertNormal(arg0: Kratos.ConditionsArray) -> None

    3. InvertNormal(arg0: Kratos.ElementsArray, arg1: Kratos.Flags) -> None

    4. InvertNormal(arg0: Kratos.ConditionsArray, arg1: Kratos.Flags) -> None
    """
