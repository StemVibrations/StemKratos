import KratosMultiphysics as Kratos
import KratosMultiphysics as Kratos
import collections.abc

def CheckValidityOfModelPartsForOperations(main_model_part: Kratos.ModelPart, list_of_checking_model_parts: collections.abc.Sequence[Kratos.ModelPart], thow_error: bool) -> bool:
    """CheckValidityOfModelPartsForOperations(main_model_part: Kratos.ModelPart, list_of_checking_model_parts: collections.abc.Sequence[Kratos.ModelPart], thow_error: bool) -> bool"""
def HasIntersection(model_parts_to_intersect: collections.abc.Sequence[Kratos.ModelPart]) -> bool:
    """HasIntersection(model_parts_to_intersect: collections.abc.Sequence[Kratos.ModelPart]) -> bool"""
def Intersect(output_sub_model_part: Kratos.ModelPart, main_model_part: Kratos.ModelPart, model_parts_to_intersect: collections.abc.Sequence[Kratos.ModelPart], add_neighbours: bool) -> None:
    """Intersect(output_sub_model_part: Kratos.ModelPart, main_model_part: Kratos.ModelPart, model_parts_to_intersect: collections.abc.Sequence[Kratos.ModelPart], add_neighbours: bool) -> None"""
def Substract(output_sub_model_part: Kratos.ModelPart, main_model_part: Kratos.ModelPart, model_parts_to_substract: collections.abc.Sequence[Kratos.ModelPart], add_neighbours: bool) -> None:
    """Substract(output_sub_model_part: Kratos.ModelPart, main_model_part: Kratos.ModelPart, model_parts_to_substract: collections.abc.Sequence[Kratos.ModelPart], add_neighbours: bool) -> None"""
def Union(output_sub_model_part: Kratos.ModelPart, main_model_part: Kratos.ModelPart, model_parts_to_merge: collections.abc.Sequence[Kratos.ModelPart], add_neighbours: bool) -> None:
    """Union(output_sub_model_part: Kratos.ModelPart, main_model_part: Kratos.ModelPart, model_parts_to_merge: collections.abc.Sequence[Kratos.ModelPart], add_neighbours: bool) -> None"""
