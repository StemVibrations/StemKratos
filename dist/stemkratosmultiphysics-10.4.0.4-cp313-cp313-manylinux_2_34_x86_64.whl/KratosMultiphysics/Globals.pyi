import KratosMultiphysics as Kratos
import typing
from typing import ClassVar

class DataLocation:
    """Members:

      NodeHistorical

      NodeNonHistorical

      Element

      Condition

      ProcessInfo

      ModelPart"""
    __members__: ClassVar[dict] = ...  # read-only
    Condition: ClassVar[DataLocation] = ...
    Element: ClassVar[DataLocation] = ...
    ModelPart: ClassVar[DataLocation] = ...
    NodeHistorical: ClassVar[DataLocation] = ...
    NodeNonHistorical: ClassVar[DataLocation] = ...
    ProcessInfo: ClassVar[DataLocation] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: typing.SupportsInt) -> None:
        """__init__(self: Kratos.Globals.DataLocation, value: typing.SupportsInt) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object, /) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object, /) -> int"""
    def __index__(self) -> int:
        """__index__(self: Kratos.Globals.DataLocation, /) -> int"""
    def __int__(self) -> int:
        """__int__(self: Kratos.Globals.DataLocation, /) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object, /) -> bool"""
    @property
    def name(self) -> str:
        """name(self: object, /) -> str

        name(self: object, /) -> str
        """
    @property
    def value(self) -> int:
        """(arg0: Kratos.Globals.DataLocation) -> int"""
