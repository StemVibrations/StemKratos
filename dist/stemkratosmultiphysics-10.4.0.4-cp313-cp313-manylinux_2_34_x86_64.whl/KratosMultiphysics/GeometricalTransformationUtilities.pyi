import KratosMultiphysics as Kratos
import KratosMultiphysics as Kratos
import typing

def CalculateRotationMatrix(arg0: typing.SupportsFloat, arg1: Kratos.Matrix, arg2: Kratos.Vector, arg3: Kratos.Vector) -> None:
    """CalculateRotationMatrix(arg0: typing.SupportsFloat, arg1: Kratos.Matrix, arg2: Kratos.Vector, arg3: Kratos.Vector) -> None"""
def CalculateTranslationMatrix(arg0: typing.SupportsFloat, arg1: Kratos.Matrix, arg2: Kratos.Vector) -> None:
    """CalculateTranslationMatrix(arg0: typing.SupportsFloat, arg1: Kratos.Matrix, arg2: Kratos.Vector) -> None"""
