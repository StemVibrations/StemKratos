import KratosMultiphysics as Kratos
import KratosMultiphysics as Kratos
import typing

class KratosRailwayApplication(Kratos.KratosApplication):
    def __init__(self) -> None:
        """__init__(self: KratosRailwayApplication.KratosRailwayApplication) -> None"""

class UvecUtilities:
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""
    @staticmethod
    def GetMovingConditionVariable(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> Kratos.Array3:
        """GetMovingConditionVariable(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3) -> Kratos.Array3"""
    @staticmethod
    def SetLoadOnCondition(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None:
        """SetLoadOnCondition(arg0: Kratos.ModelPart, arg1: Kratos.Array1DVariable3, arg2: typing.SupportsFloat) -> None"""
